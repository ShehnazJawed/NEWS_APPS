package com.example.news_app;

import com.example.news_app.Models.NewsHeadlines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadlines headlines);

}
